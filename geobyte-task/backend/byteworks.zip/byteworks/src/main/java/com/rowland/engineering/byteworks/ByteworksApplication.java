package com.rowland.engineering.byteworks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ByteworksApplication {

	public static void main(String[] args) {
		SpringApplication.run(ByteworksApplication.class, args);
	}

}
